DROP TABLE music;
DROP TABLE userinfo;
DROP TABLE musicArtist;